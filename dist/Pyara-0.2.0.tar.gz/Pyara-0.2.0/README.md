Code for synthesized speech recognition system
